#ifndef FONTS_H
#define FONTS_H

unsigned char get_font_row_8x8(unsigned char ch, unsigned char row);
unsigned char get_font_row_4x4(unsigned char ch, unsigned char row);

#endif
