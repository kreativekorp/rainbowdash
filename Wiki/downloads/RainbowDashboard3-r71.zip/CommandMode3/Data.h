#ifndef DATA_H
#define DATA_H

unsigned char get_prefab(unsigned char pi, unsigned char color, unsigned char row, unsigned char column);
unsigned char get_font(unsigned char index, unsigned char row);
unsigned char asc_to_idx(unsigned char ascii);

#endif
