#ifndef RAINBOOM_H
#define RAINBOOM_H

void video_set_buffer(unsigned char * buffer);
void video_set_next_buffer(unsigned char * buffer);
void video_setup(void);
void video_loop(void);

#endif
